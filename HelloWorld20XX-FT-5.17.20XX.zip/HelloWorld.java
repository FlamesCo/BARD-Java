// @FlamesLLC 20XX - [C]

public class HelloWorld {

    public static void main(String[] args) {

        // Prints "Hello, World!" to the console.
        System.out.println("Hello, World!");

    }

}
